$(".news-t-1").click(function(){
    window.location.href="news_details.html"
})

$(".news-t-2").click(function(){
    window.location.href="news_details.html"
})

$(".news-t-3").click(function(){
    window.location.href="news_details.html"
})

       
$(".section-4 .new-show-content:nth-child(3n+1)").css({"margin-left":"0"})